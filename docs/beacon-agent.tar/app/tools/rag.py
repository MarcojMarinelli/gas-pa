from __future__ import annotations
import os
import json
import logging
from typing import Any, Dict, List, Optional, Tuple

import requests
from app.config import settings

log = logging.getLogger(__name__)

def _kv(items):
    return ", ".join(f"{k}={v}" for k, v in items.items())

class RAGClient:
    """Adaptive HTTP client for the Beacon RAG API.

    Tries common paths/methods and normalizes results:
      - Paths: /api/search, /search, /v1/search, /query, /v1/query, /rag/search
      - Methods: POST then GET (backend prefers POST)
      - Shapes: {q,top_k,filters} | {question,k}

    Env:
      - RAG_BASE_URL       (e.g., http://rag-backend:9000)
      - RAG_API_KEY        (Bearer token)
      - RAG_SEARCH_PATH    (default: /api/search)
      - RAG_METHOD         (default: POST)
      - RAG_FILTER_KEY     (filters | filter; default: filters)
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        method: Optional[str] = None,
        path: Optional[str] = None,
        filter_key: Optional[str] = None,
        timeout: int = 20,
    ):
        self.base_url = (base_url or settings.RAG_BASE_URL).rstrip("/")
        self.api_key = api_key or settings.RAG_API_KEY
        self.method = (method or os.getenv("RAG_METHOD", "POST")).upper()
        self.path = path or os.getenv("RAG_SEARCH_PATH", "/api/search")
        self.filter_key = filter_key or os.getenv("RAG_FILTER_KEY", "filters")
        self.timeout = timeout

    # ------------------------------- helpers --------------------------------

    def _headers(self) -> Dict[str, str]:
        h = {"Accept": "application/json", "User-Agent": "beacon-agent/1.0"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def _request(self, method: str, path: str, *, params: Dict[str, Any] | None = None, json_body: Dict[str, Any] | None = None):
        url = f"{self.base_url}{path}"
        log.debug("RAG %s %s params=%s json=%s", method, url, params, json_body)
        return requests.request(method, url, params=params, json=json_body, headers=self._headers(), timeout=self.timeout)

    # ------------------------------- public ---------------------------------

    # inside class RAGClient:
    def qna(self, question: str, k: int = 4) -> dict:
        r = requests.post( f"{self.base_url}/query", json={"question": question, "k": k}, headers=self._headers(), timeout=self.timeout,)
        if r.status_code == 401:
            raise RuntimeError("RAG API returned 401 Unauthorized. Check RAG_API_KEY.")
            r.raise_for_status()
        return r.json()

    def search(self, q: str, top_k: int = 6, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        errors: List[Tuple[str, int, str]] = []
        fkey = self.filter_key

        # 1) Primary: POST /api/search with {"q","top_k","filters"}
        try:
            r = self._request("POST", self.path, json_body={"q": q, "top_k": top_k, fkey: (filters or {})})
            if r.status_code == 401:
                raise RuntimeError("RAG API returned 401 Unauthorized. Check RAG_API_KEY.")
            if r.ok:
                return r.json()
            errors.append((f"POST {self.path}", r.status_code, (r.text or "")[:200]))
        except Exception as e:
            errors.append((f"POST {self.path}", 0, str(e)))

        # 2) Fallback: POST /query with {"question","k"} and normalize to {"results":[...]}
        try:
            r = self._request("POST", "/query", json_body={"question": q, "k": top_k})
            if r.status_code == 401:
                raise RuntimeError("RAG API returned 401 Unauthorized. Check RAG_API_KEY.")
            if r.ok:
                data = r.json()
                return {"results": data.get("results", [])}
            errors.append(("POST /query", r.status_code, (r.text or "")[:200]))
        except Exception as e:
            errors.append(("POST /query", 0, str(e)))

        # 3) Last resort: GET /search (filters as JSON string)
        try:
            params = {"q": q, "top_k": top_k}
            if filters is not None:
                params[fkey] = json.dumps(filters)
            r = self._request("GET", "/search", params=params)
            if r.status_code == 401:
                raise RuntimeError("RAG API returned 401 Unauthorized. Check RAG_API_KEY.")
            if r.ok:
                return r.json()
            errors.append(("GET /search", r.status_code, (r.text or "")[:200]))
        except Exception as e:
            errors.append(("GET /search", 0, str(e)))

        msg = "\n".join(f"- {m}: HTTP {code} {body}" for (m, code, body) in errors[:8])
        raise RuntimeError("All RAG attempts failed.\n" + msg)

    def search_customer(self, q: str, account_id: str = "acme", top_k: int = 6, **filters) -> Dict[str, Any]:
        base_filters = {"corpus": "customer", "account_id": account_id}
        base_filters.update({k: v for k, v in filters.items() if v is not None})
        return self.search(q=q, top_k=top_k, filters=base_filters)

    def search_process(self, q: str, framework: Optional[str] = None, top_k: int = 6, **filters) -> Dict[str, Any]:
        base_filters = {"corpus": "process"}
        if framework:
            base_filters["framework"] = framework
        base_filters.update({k: v for k, v in filters.items() if v is not None})
        return self.search(q=q, top_k=top_k, filters=base_filters)

# convenience instance
client = RAGClient()

def find_last_meeting(account_id: str = "acme", limit: int = 3):
    filters = {
        "corpus": "customer",
        "account_id": account_id,
        "source_type": ["calendar", "zoom", "slack"],
    }
    res = client.search(q="last meeting notes action items", top_k=max(limit, 6), filters=filters)
    items = res.get("results") or res.get("documents") or res.get("items") or []
    # sort newest-first
    def _date(md: Dict[str, Any]):
        return md.get("event_date") or md.get("sent_at") or md.get("ingested_at") or ""
    try:
        items.sort(key=lambda it: _date(it.get("metadata") or it.get("metadatas") or {}), reverse=True)
    except Exception:
        pass
    return items[:limit]

