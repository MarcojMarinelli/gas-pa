
from __future__ import annotations
from slack_sdk import WebClient

def reply_in_thread(client: WebClient, channel: str, thread_ts: str, text: str, blocks=None):
    return client.chat_postMessage(channel=channel, thread_ts=thread_ts, text=text, blocks=blocks)

def post_ephemeral(client: WebClient, channel: str, user: str, text: str):
    return client.chat_postEphemeral(channel=channel, user=user, text=text)

def add_reaction(client: WebClient, channel: str, timestamp: str, name: str):
    try:
        client.reactions_add(channel=channel, timestamp=timestamp, name=name)
    except Exception:
        pass  # don't fail if reaction isn't allowed
