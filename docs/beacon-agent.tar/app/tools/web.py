
from __future__ import annotations
import typing as t
from pydantic import BaseModel, Field
from tavily import TavilyClient

class WebHit(BaseModel):
    url: str
    title: str | None = None
    published_date: str | None = None
    content: str | None = None
    score: float | None = None

class WebQuery(BaseModel):
    q: str = Field(..., description="Search query")
    max_results: int = 5

def web_search(tavily_api_key: str, q: WebQuery) -> list[WebHit]:
    client = TavilyClient(api_key=tavily_api_key)
    res = client.search(q.q, max_results=q.max_results)
    hits = []
    for item in res.get("results", []):
        hits.append(WebHit(
            url=item.get("url"),
            title=item.get("title"),
            content=item.get("content"),
            published_date=item.get("published_date"),
            score=item.get("score"),
        ))
    return hits
