import os, re, json, logging, datetime
from typing import List, Dict, Any, Optional

from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler
from slack_sdk.errors import SlackApiError

# use your existing adaptive client
from app.tools.rag import client as rag

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger("beacon")

SLACK_BOT_TOKEN = os.getenv("SLACK_BOT_TOKEN")
SLACK_APP_TOKEN = os.getenv("SLACK_APP_TOKEN")
SLACK_SIGNING_SECRET = os.getenv("SLACK_SIGNING_SECRET", "")

if not SLACK_BOT_TOKEN or not SLACK_APP_TOKEN:
    raise SystemExit("Missing SLACK_BOT_TOKEN or SLACK_APP_TOKEN")

app = App(token=SLACK_BOT_TOKEN, signing_secret=SLACK_SIGNING_SECRET)

# fetch bot user id at startup
auth = app.client.auth_test()
BOT_USER_ID = auth["user_id"]
MENTION_RE = re.compile(rf"<@{BOT_USER_ID}>")

def strip_first_mention(text: str) -> str:
    if not text:
        return ""
    return MENTION_RE.sub("", text, count=1).strip()

def reply_in_thread(client, channel: str, thread_ts: str, text: str):
    client.chat_postMessage(channel=channel, text=text, thread_ts=thread_ts)

def _pick_date(md: Dict[str, Any]) -> str:
    # prefer explicit event_date/sent_at, fall back to ingested_at
    return md.get("event_date") or md.get("sent_at") or md.get("ingested_at") or ""

def _extract_actions(doc: str) -> List[str]:
    if not doc:
        return []
    lines = []
    for line in doc.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.lower().startswith(("next steps", "actions", "action items", "action points")):
            continue
        if s.startswith(("-", "•", "*")) or re.match(r"^\d+[\.)]\s+", s):
            s = re.sub(r"^[\-\*•]\s*", "", s)            # strip bullets
            s = re.sub(r"^\d+[\.)]\s+", "", s)           # strip numbering
            if len(s) >= 3:
                lines.append(s)
    # dedupe, cap to 10
    seen, out = set(), []
    for l in lines:
        if l not in seen:
            seen.add(l); out.append(l)
        if len(out) >= 10: break
    return out

def _format_sources(items: List[Dict[str, Any]]) -> str:
    rows = []
    for it in items[:5]:
        md = it.get("metadata") or it.get("metadatas") or {}
        st = md.get("source_type") or "source"
        fn = md.get("file_name") or md.get("id") or "doc"
        dt = _pick_date(md)
        rows.append(f"• {st} — {fn}" + (f" ({dt})" if dt else ""))
    return "\n".join(rows) if rows else "• (no sources)"

def handle_last_meeting(channel: str, thread_ts: str):
    # search across calendar/zoom/slack for ACME
    filters = {
        "corpus": "customer",
        "account_id": "acme",
        "source_type": ["calendar", "zoom", "slack"],
    }
    res = rag.search(q="last meeting notes action items", top_k=8, filters=filters)
    items = res.get("results") or []
    if not items:
        reply_in_thread(app.client, channel, thread_ts, "I couldn't find any ACME meetings yet.")
        return

    # sort newest first
    def _key(it):
        md = it.get("metadata") or it.get("metadatas") or {}
        return _pick_date(md)
    items.sort(key=_key, reverse=True)

    top = items[0]
    md  = top.get("metadata") or top.get("metadatas") or {}
    doc = top.get("document") or top.get("text") or ""

    date = _pick_date(md) or "(date unknown)"
    title = md.get("file_name") or md.get("id") or "latest meeting"
    actions = _extract_actions(doc)
    sources_md = _format_sources(items)

    if not actions:
        actions_md = "_No explicit action bullets found; check the sources below._"
    else:
        actions_md = "\n".join(f"• {a}" for a in actions)

    msg = (
        f"*Last meeting:* {date}\n"
        f"*From:* {title}\n\n"
        f"*Action points*\n{actions_md}\n\n"
        f"*Sources*\n{sources_md}"
    )
    reply_in_thread(app.client, channel, thread_ts, msg)

def handle_event(event: Dict[str, Any]):
    channel   = event.get("channel")
    text      = (event.get("text") or "").strip()
    ts        = event.get("ts")
    thread_ts = event.get("thread_ts") or ts
    subtype   = event.get("subtype")

    if subtype in {"bot_message", "message_changed", "message_deleted"}:
        return
    if f"<@{BOT_USER_ID}>" not in text:
        return

    try:
        app.client.reactions_add(channel=channel, timestamp=ts, name="eyes")
    except SlackApiError:
        pass

    cleaned = strip_first_mention(text).lower()

    if "last meeting" in cleaned and "action" in cleaned:
        handle_last_meeting(channel, thread_ts)
        return

    if cleaned in {"", "help", "ping"}:
        reply_in_thread(app.client, channel, thread_ts,
                        "👋 I’m here. Try: `@beacon when was the last meeting and what were the action points`")
        return

    reply_in_thread(app.client, channel, thread_ts, f"🧠 Heard: `{cleaned}` (other intents coming soon).")

@app.event("app_mention")
def on_app_mention(event, say):
    handle_event(event)

@app.event("message")
def on_message(event):
    handle_event(event)

if __name__ == "__main__":
    print("🚀 Beacon listening in Socket Mode…")
    SocketModeHandler(app, SLACK_APP_TOKEN).start()

