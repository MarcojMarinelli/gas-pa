
from __future__ import annotations
import sqlite3, os
from datetime import datetime

class ThreadMemory:
    def __init__(self, db_path: str):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db = sqlite3.connect(db_path, check_same_thread=False)
        self._init()

    def _init(self):
        cur = self.db.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS messages (
                thread_ts TEXT,
                role TEXT,
                content TEXT,
                ts TEXT
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS summaries (
                thread_ts TEXT PRIMARY KEY,
                summary TEXT,
                updated_at TEXT
            )
            """
        )
        self.db.commit()

    def append(self, thread_ts: str, role: str, content: str, ts: str | None = None):
        cur = self.db.cursor()
        cur.execute(
            "INSERT INTO messages (thread_ts, role, content, ts) VALUES (?, ?, ?, ?)",
            (thread_ts, role, content, ts or datetime.utcnow().isoformat()),
        )
        self.db.commit()

    def get_messages(self, thread_ts: str, limit: int = 50):
        cur = self.db.cursor()
        cur.execute(
            "SELECT role, content, ts FROM messages WHERE thread_ts=? ORDER BY ts ASC",
            (thread_ts,),
        )
        rows = cur.fetchall()
        if limit and len(rows) > limit:
            rows = rows[-limit:]
        return [{"role": r, "content": c, "ts": t} for (r, c, t) in rows]

    def get_summary(self, thread_ts: str) -> str | None:
        cur = self.db.cursor()
        cur.execute("SELECT summary FROM summaries WHERE thread_ts=?", (thread_ts,))
        row = cur.fetchone()
        return row[0] if row else None

    def upsert_summary(self, thread_ts: str, summary: str):
        cur = self.db.cursor()
        cur.execute(
            """
            INSERT INTO summaries (thread_ts, summary, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(thread_ts) DO UPDATE SET
                summary=excluded.summary,
                updated_at=excluded.updated_at
            """,
            (thread_ts, summary, datetime.utcnow().isoformat()),
        )
        self.db.commit()
