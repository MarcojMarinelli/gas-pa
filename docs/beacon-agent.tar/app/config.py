import os
from dataclasses import dataclass

@dataclass
class Settings:
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL_RESPONSE: str = os.getenv("OPENAI_MODEL_RESPONSE", "gpt-4o")
    OPENAI_MODEL_REASONING: str = os.getenv("OPENAI_MODEL_REASONING", "o3-pro")

    SLACK_BOT_TOKEN: str = os.getenv("SLACK_BOT_TOKEN", "")
    SLACK_SIGNING_SECRET: str = os.getenv("SLACK_SIGNING_SECRET", "")
    SLACK_APP_TOKEN: str = os.getenv("SLACK_APP_TOKEN", "")

    RAG_BASE_URL: str = os.getenv("RAG_BASE_URL", "https://beacon.maranet.cc")
    RAG_API_KEY: str = os.getenv("RAG_API_KEY", "")

    TAVILY_API_KEY: str = os.getenv("TAVILY_API_KEY", "")

settings = Settings()
