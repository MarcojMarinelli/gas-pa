
from __future__ import annotations
from typing import List, Dict, Any
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field

class GapReport(BaseModel):
    covered: Dict[str, str]  # pillar -> brief evidence
    gaps: Dict[str, str]     # pillar -> what to find next

class ThreeWhys(BaseModel):
    why_change: str
    why_now: str
    why_us: str

MEDDPIC_PILLARS = ["Metrics", "Economic Buyer", "Decision Criteria", "Decision Process", "Paper Process", "Implicate Pain", "Champion"]

def meddpic_gap(llm: ChatOpenAI, evidence: List[Dict[str, Any]]) -> GapReport:
    prompt = [
        ("system","You extract MEDDPIC coverage from evidence and produce JSON."),
        ("user", f"Pillars: {MEDDPIC_PILLARS}\nEvidence: {evidence[:20]}\nReturn JSON with 'covered' (pillar->evidence) and 'gaps' (pillar->missing info).")
    ]
    return llm.with_structured_output(GapReport).invoke(prompt)

def cotm_three_whys(llm: ChatOpenAI, evidence: List[Dict[str, Any]]) -> ThreeWhys:
    prompt = [
        ("system","Using 'Customer's Operating & Transformation Model (COTM)' or similar process docs, infer the three whys."),
        ("user", f"Evidence: {evidence[:20]}\nReturn JSON with keys why_change, why_now, why_us.")
    ]
    return llm.with_structured_output(ThreeWhys).invoke(prompt)
