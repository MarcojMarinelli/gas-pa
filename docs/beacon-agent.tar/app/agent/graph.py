
from __future__ import annotations
from typing import Dict, Any
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint import MemorySaver
from langchain_openai import ChatOpenAI
from app.tools import rag as rag_tool
from app.tools import web as web_tool

AgentState = dict

def build_executor(reasoning_model: str, general_model: str, openai_api_key: str, tavily_key: str | None = None):
    reasoning_llm = ChatOpenAI(model=reasoning_model, api_key=openai_api_key, temperature=0.1)
    general_llm = ChatOpenAI(model=general_model, api_key=openai_api_key, temperature=0.2)

    memory = MemorySaver()  # in-proc by default

    graph = StateGraph(AgentState)

    def node_rag_customer(state: AgentState):
        q = state.get("current_step", {}).get("inputs", {}).get("q") or state["query"]
        account = state.get("account_id", "acme")
        res = rag_tool.search_customer(q=q, account_id=account)
        state.setdefault("evidence", []).extend([{"type":"customer", "doc": r.document, "meta": r.metadata} for r in res])
        state["step_index"] += 1
        return state

    def node_rag_process(state: AgentState):
        q = state.get("current_step", {}).get("inputs", {}).get("q") or state["query"]
        res = rag_tool.search_process(q=q)
        state.setdefault("evidence", []).extend([{"type":"process", "doc": r.document, "meta": r.metadata} for r in res])
        state["step_index"] += 1
        return state

    def node_rag_both(state: AgentState):
        node_rag_process(state)
        node_rag_customer(state)
        return state

    def node_web(state: AgentState):
        if not tavily_key:
            state.setdefault("warnings", []).append("Web search not configured (missing TAVILY_API_KEY)")
            state["step_index"] += 1
            return state
        q = state.get("current_step", {}).get("inputs", {}).get("q") or state["query"]
        hits = web_tool.web_search(tavily_api_key=tavily_key, q=web_tool.WebQuery(q=q, max_results=5))
        state.setdefault("web_hits", []).extend([h.model_dump() for h in hits])
        state["step_index"] += 1
        return state

    def node_ask_user(state: AgentState):
        # Create a narrow clarification prompt
        query = state["query"]
        msgs = [
            ("system", "You will produce a short, single-sentence clarification question. No preamble."),
            ("user", f"User asked: {query}. What single missing detail would unblock answering?")
        ]
        question = reasoning_llm.invoke(msgs).content.strip()
        state["requires_clarification"] = True
        state["clarify_prompt"] = question
        # We stop here; the outer app posts this question and waits for user reply in the same thread.
        return state

    def node_summarize(state: AgentState):
        sys = open('app/prompts/system.md', 'r').read()
        evidence = state.get("evidence", [])
        web_hits = state.get("web_hits", [])
        query = state["query"]
        msgs = [
            ("system", sys),
            ("user", f"Question: {query}\n\nEvidence (RAG): {evidence[:10]}\n\nWeb hits: {web_hits[:5]}\n\nWrite a concise answer suitable for Slack. If dates are present, include them. End with a short 'Sources:' list.")
        ]
        out = general_llm.invoke(msgs)
        state["final_answer"] = out.content
        state["step_index"] += 1
        return state

    def router(state: AgentState):
        idx = state.get("step_index", 0)
        steps = state.get("plan_steps", [])
        if idx >= len(steps):
            return "final"
        step = steps[idx]
        state["current_step"] = step
        tool = step.get("tool")
        return {"rag_customer": "rag_customer",
                "rag_process": "rag_process",
                "rag_both": "rag_both",
                "web": "web",
                "ask_user": "ask_user",
                "final_summarize": "final"}[tool]

    # nodes
    graph.add_node("rag_customer", node_rag_customer)
    graph.add_node("rag_process", node_rag_process)
    graph.add_node("rag_both", node_rag_both)
    graph.add_node("web", node_web)
    graph.add_node("ask_user", node_ask_user)
    graph.add_node("final", node_summarize)
    graph.add_node("router", router)

    # edges
    graph.add_edge(START, "router")
    graph.add_conditional_edges("router", router, {"rag_customer":"rag_customer","rag_process":"rag_process","rag_both":"rag_both","web":"web","ask_user":"ask_user","final":"final"})
    for n in ["rag_customer","rag_process","rag_both","web","ask_user"]:
        graph.add_edge(n, "router")
    graph.add_edge("final", END)

    app = graph.compile(checkpointer=memory)
    return app
