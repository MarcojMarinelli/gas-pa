
from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Literal, List, Optional, Dict, Any
from langchain_openai import ChatOpenAI

class PlanStep(BaseModel):
    id: str
    tool: Literal["rag_customer", "rag_process", "rag_both", "web", "ask_user", "final_summarize"]
    description: str
    inputs: Dict[str, Any] = Field(default_factory=dict)

class Plan(BaseModel):
    steps: List[PlanStep]
    rationale: str

PLANNER_SYSTEM = """You are a senior sales copilot for LogicMonitor.
Create an execution plan as JSON for the user's request.
- Prefer RAG over web unless the user explicitly asks for outside news.
- If the user asks about account 'acme', set account_id='acme'.
- If MEDDPIC/COTM appears, consult process corpus and cross-check customer corpus.
- Use ask_user when *truly* missing critical details.
- Always end with a 'final_summarize' step."""

PLANNER_USER_TEMPLATE = """Request: {query}
Thread Summary (optional): {summary}
Recent Messages (optional): {messages}"""

def build_planner(model_name: str, api_key: str):
    return ChatOpenAI(model=model_name, api_key=api_key, temperature=0.2)

def plan(planner_llm: ChatOpenAI, query: str, summary: str | None, recent_msgs: list[dict] | None) -> Plan:
    prompt = [
        ("system", PLANNER_SYSTEM),
        ("user", PLANNER_USER_TEMPLATE.format(query=query, summary=summary or "", messages=recent_msgs or []))
    ]
    resp = planner_llm.with_structured_output(Plan).invoke(prompt)
    return resp
