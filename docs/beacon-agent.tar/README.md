
# Beacon Agent (Slack + LangGraph + RAG)

Production-ready scaffold for a Slack agent called **beacon** that:
- Runs in Docker on Ubuntu (via `docker-compose`)
- Uses **LangChain** + **LangGraph** for plan-and-execute
- Replies in the same Slack thread
- Pulls from a remote **RAG API** (`https://beacon.maranet.cc`) with the provided schema
- Searches the web (Tavily)
- Keeps lightweight **thread memory** (SQLite) and optional **LangGraph checkpoints** (Redis)
- Uses OpenAI models (configurable; defaults to `gpt-5` + `o3-pro` if available, falls back safely)

> This is a working skeleton intended for quick start. You will need to add your Slack App credentials, OpenAI key, Tavily key, and (if needed) Redis credentials in a `.env` file.

## Quick start

```bash
cp .env.example .env
# edit .env with your keys
docker compose up --build
```

The agent runs in **Socket Mode** (no public HTTP URL required).

## Slack App Setup (high level)

1. Create a Slack App (from scratch) and install it to your workspace.
2. Enable **Socket Mode** and copy the **App Token** (`xapp-...`).
3. Enable **Events API** and subscribe to:
   - `app_mention`
   - `message.channels`
4. Add **Bot Token Scopes**: `app_mentions:read`, `channels:history`, `chat:write`, `files:read`, `files:write`, `reactions:write` (adjust as needed).
5. Add the bot to your channel (e.g., `#account-acme`). Mentions look like `@beacon ...`.

## RAG API

This project assumes an HTTP API at `https://beacon.maranet.cc` that returns chunks with the schema you shared (Chroma-style):
- `corpus`: `customer` | `process`
- `source_type`: `email` | `calendar` | `sfdc` | `zoom` | `slack` | `doc`
- `account_id`: `"acme"` for customer corpus
- `framework`, `pillar`, `framework_version` for process corpus, etc.

The default retriever issues filtered queries (see `app/tools/rag.py`). Adapt the endpoint paths to your deployment.

## Models

- **Reasoning / planning**: defaults to `o3-pro` (if your account has it), else `gpt-4o`, else `gpt-4.1`.
- **General responses**: defaults to `gpt-5` (if available), else `gpt-4o`.
- You can override in `.env`.

## What’s in here

- `docker-compose.yml`: agent + optional Redis
- `Dockerfile`: Python 3.11 slim + system deps
- `app/main.py`: Slack Bolt app, message router, plan/execute call
- `app/agent/graph.py`: LangGraph plan-and-execute agent
- `app/agent/planner.py`: Planner prompt + structured plan schema
- `app/tools/rag.py`: RAG REST retriever (customer/process/all)
- `app/tools/web.py`: Tavily search tool
- `app/tools/slack_io.py`: Slack helpers (threaded replies, ask-user)
- `app/memory/sqlite_store.py`: lightweight per-thread memory (buffer + rolling summary)
- `app/prompts/system.md`: system guidance for tone and guardrails
- `app/config.py`: env config
- `.env.example`: env template

## Example queries you can run in Slack

- `@beacon when was the last meeting and what were the action points?`
- `@beacon tell me where we have gaps in the MEDDPIC process`
- `@beacon according to COTM what are the 3 whys for the acme opportunity`
- `@beacon what is the latest news on acme`

## Notes

- Replies always go to the **same Slack thread** (using `thread_ts`).  
- When additional info is required, the agent **asks a clarifying question** in the thread and pauses until a follow-up message arrives in that thread.
- The SQLite memory file is persisted to a Docker volume for continuity across restarts.

MIT License (c) 2025
