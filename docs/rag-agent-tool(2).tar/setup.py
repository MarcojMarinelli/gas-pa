from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="rag-agent-tool",
    version="1.0.0",
    author="AI Agent Development Team",
    description="RAG Query Analysis and Execution Planning Agent",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.9",
    install_requires=[
        "langchain>=0.1.0",
        "langgraph>=0.0.20",
        "openai>=1.12.0",
        "fastapi>=0.109.0",
        "pydantic>=2.5.0",
    ],
    entry_points={
        "console_scripts": [
            "rag-agent=src.main:main",
        ],
    },
)