# RAG Agent Tool

A sophisticated AI Agent tool for query analysis and execution planning using OpenAI API and LangChain/LangGraph.

## Features

- 🔍 Intelligent Query Analysis with schema-aware optimization
- 🎯 Dynamic Persona Adaptation for contextual responses
- 📊 Adaptive Retrieval with dynamic k-value selection
- 💾 Advanced Caching System with LRU and TTL support
- 📈 Comprehensive Metrics Collection
- 🔄 Full LangChain/LangGraph Integration
- 🚀 Production-ready FastAPI Backend

## Quick Start

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Configure environment:
```bash
cp .env.example .env
# Edit .env with your OpenAI API key
```

3. Run the application:
```bash
python -m src.main
```

The API will be available at http://localhost:8000

## API Usage

```bash
curl -X POST "http://localhost:8000/query" \
  -H "Content-Type: application/json" \
  -d '{"question": "What was discussed in the last Acme meeting?"}'
```

## Docker Deployment

```bash
docker-compose up -d
```

## License

MIT