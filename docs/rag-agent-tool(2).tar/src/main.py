"""Main entry point for RAG Agent Tool"""

import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any

from .agents.orchestrator import AIAgent
from .config import settings

app = FastAPI(
    title="RAG Agent Tool",
    description="Query Analysis and Execution Planning Agent",
    version="1.0.0"
)

agent = AIAgent()

class QueryRequest(BaseModel):
    question: str
    context: Optional[Dict[str, Any]] = None

class QueryResponse(BaseModel):
    response: str
    sources: list
    metadata: Dict[str, Any]

@app.post("/query", response_model=QueryResponse)
async def process_query(request: QueryRequest):
    """Process a user query through the RAG agent"""
    try:
        result = await agent.process_question(
            user_question=request.question,
            context=request.context or {}
        )
        return QueryResponse(
            response=result["response"],
            sources=result.get("sources", []),
            metadata=result.get("metadata", {})
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "version": "1.0.0"}

def main():
    uvicorn.run(app, host="0.0.0.0", port=8000)

if __name__ == "__main__":
    main()