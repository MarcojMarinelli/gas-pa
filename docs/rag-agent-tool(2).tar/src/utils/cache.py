"""Cache management for the agent system"""

from typing import Any, Optional
from datetime import datetime, timedelta
from collections import OrderedDict
import hashlib
import json

class CacheManager:
    """LRU cache with TTL support"""
    
    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self.cache = OrderedDict()
    
    async def get(self, key: str) -> Optional[Any]:
        """Get item from cache"""
        if key in self.cache:
            item = self.cache[key]
            if datetime.utcnow() > item["expiry"]:
                del self.cache[key]
                return None
            self.cache.move_to_end(key)
            return item["value"]
        return None
    
    async def set(self, key: str, value: Any, ttl: int = 3600) -> bool:
        """Set item in cache"""
        if len(self.cache) >= self.max_size:
            self.cache.popitem(last=False)
        
        self.cache[key] = {
            "value": value,
            "expiry": datetime.utcnow() + timedelta(seconds=ttl)
        }
        self.cache.move_to_end(key)
        return True
    
    def generate_key(self, *args) -> str:
        """Generate cache key"""
        key_data = json.dumps(args, sort_keys=True, default=str)
        return hashlib.sha256(key_data.encode()).hexdigest()