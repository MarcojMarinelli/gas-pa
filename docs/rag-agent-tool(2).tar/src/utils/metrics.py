"""Metrics collection for monitoring"""

from typing import Dict, Any
from datetime import datetime
from collections import defaultdict

class MetricsCollector:
    """Collects system metrics"""
    
    def __init__(self):
        self.metrics = defaultdict(list)
        self.start_time = datetime.utcnow()
        self.request_count = 0
        self.error_count = 0
    
    def record_request(self, duration: float, sources_used: int, confidence: float):
        """Record request metrics"""
        self.request_count += 1
        self.metrics["duration"].append(duration)
        self.metrics["sources_used"].append(sources_used)
        self.metrics["confidence"].append(confidence)
    
    def get_summary(self) -> Dict[str, Any]:
        """Get metrics summary"""
        uptime = (datetime.utcnow() - self.start_time).total_seconds()
        return {
            "uptime_seconds": uptime,
            "total_requests": self.request_count,
            "total_errors": self.error_count,
            "requests_per_minute": self.request_count / max(uptime / 60, 1)
        }