"""RAG Agent Tool - Query Analysis and Execution Planning"""

__version__ = "1.0.0"
__author__ = "AI Agent Development Team"

from .agents.orchestrator import AIAgent

__all__ = ["AIAgent"]