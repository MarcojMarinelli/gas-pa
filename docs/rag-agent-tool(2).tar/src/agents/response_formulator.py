"""Response formulation module for generating contextual answers"""

import json
from typing import Dict, Any, List
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.chat_models import ChatOpenAI
from ..config import settings

class ResponseFormulator:
    """Formulates responses using RAG data and context"""
    
    def __init__(self):
        self.llm = ChatOpenAI(
            model_name=settings.openai.model_name,
            temperature=0.5,
            openai_api_key=settings.openai.api_key
        )
        self.response_prompt = self._create_response_prompt()
        self.response_chain = LLMChain(llm=self.llm, prompt=self.response_prompt)
    
    def _create_response_prompt(self) -> PromptTemplate:
        template = """You are a LogicMonitor Sales Copilot with MEDDPICC expertise.
        
        Question: {question}
        
        RAG Data: {rag_data}
        
        Context: {context}
        
        Generate a comprehensive response that:
        1. Answers based ONLY on RAG data
        2. Cites sources appropriately
        3. Maintains professional sales tone
        4. Focuses on actionable insights
        """
        
        return PromptTemplate(
            input_variables=["question", "rag_data", "context"],
            template=template
        )
    
    async def generate_response(self, rag_results: List[Dict], user_question: str, query_context: Dict) -> Dict[str, Any]:
        """Generate response using RAG data - Second API Call"""
        rag_summary = self._summarize_rag_results(rag_results)
        
        llm_input = {
            "question": user_question,
            "rag_data": json.dumps(rag_summary),
            "context": json.dumps(query_context)
        }
        
        response = await self.response_chain.arun(llm_input)
        
        return {
            "content": response,
            "sources": self._extract_sources(rag_results),
            "confidence_score": self._calculate_confidence(rag_results)
        }
    
    def _summarize_rag_results(self, results: List[Dict]) -> Dict:
        """Summarize RAG results for LLM"""
        if not results:
            return {"documents": [], "summary": "No documents found"}
        
        return {
            "documents": [
                {
                    "content": r.get("content", "")[:500],
                    "metadata": r.get("metadata", {})
                } for r in results
            ],
            "summary": f"Found {len(results)} relevant documents"
        }
    
    def _extract_sources(self, results: List[Dict]) -> List[Dict]:
        """Extract source citations"""
        return [
            {
                "file_name": r.get("metadata", {}).get("file_name", "unknown"),
                "source_type": r.get("metadata", {}).get("source_type", "unknown")
            } for r in results
        ]
    
    def _calculate_confidence(self, results: List[Dict]) -> float:
        """Calculate response confidence score"""
        if not results:
            return 0.2
        scores = [r.get("score", 0) for r in results]
        return min(sum(scores) / len(scores), 0.95)