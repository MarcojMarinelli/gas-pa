"""Query optimization module for RAG retrieval"""

import json
from typing import Dict, Any
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.chat_models import ChatOpenAI
from ..config import settings, QUERY_ENHANCEMENT_RULES

class RAGQueryOptimizer:
    """Transforms user queries for optimal RAG retrieval"""
    
    def __init__(self):
        self.llm = ChatOpenAI(
            model_name=settings.openai.model_name,
            temperature=0.3,
            openai_api_key=settings.openai.api_key
        )
        self.enhancement_rules = QUERY_ENHANCEMENT_RULES
        self.optimization_prompt = self._create_optimization_prompt()
        self.optimization_chain = LLMChain(llm=self.llm, prompt=self.optimization_prompt)
    
    def _create_optimization_prompt(self) -> PromptTemplate:
        template = """You are a RAG query optimizer. Transform the user question for optimal vector search.
        
        Original question: {question}
        Context: {context}
        Enhancement rules: {rules}
        
        Return JSON with:
        - optimized_query: optimized search query
        - k_value: number of results (2-8)
        - corpus_target: customer|process|both
        - query_strategy: explanation
        """
        
        return PromptTemplate(
            input_variables=["question", "context", "rules"],
            template=template
        )
    
    async def optimize_query(self, user_question: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize query for RAG retrieval - First API Call"""
        llm_input = {
            "question": user_question,
            "context": json.dumps(context),
            "rules": json.dumps(self.enhancement_rules)
        }
        
        response = await self.optimization_chain.arun(llm_input)
        
        try:
            optimized = json.loads(response)
        except:
            optimized = {
                "optimized_query": user_question,
                "k_value": 4,
                "corpus_target": "both",
                "query_strategy": "fallback optimization"
            }
        
        return optimized