"""Main orchestrator for the two-phase API strategy"""

from typing import Dict, Any, Optional
from datetime import datetime
from langgraph.graph import Graph, END
from .query_optimizer import RAGQueryOptimizer
from .response_formulator import ResponseFormulator
from ..rag.client import RAGClient

class AIAgent:
    """Main orchestrator implementing LangGraph workflow"""
    
    def __init__(self):
        self.query_optimizer = RAGQueryOptimizer()
        self.response_formulator = ResponseFormulator()
        self.rag_client = RAGClient()
        self._setup_workflow()
    
    def _setup_workflow(self):
        """Setup LangGraph workflow"""
        workflow = Graph()
        
        # Define nodes
        workflow.add_node("optimize_query", self._optimize_query_node)
        workflow.add_node("retrieve_rag", self._retrieve_rag_node)
        workflow.add_node("generate_response", self._generate_response_node)
        
        # Define edges
        workflow.add_edge("optimize_query", "retrieve_rag")
        workflow.add_edge("retrieve_rag", "generate_response")
        workflow.add_edge("generate_response", END)
        
        # Set entry point
        workflow.set_entry_point("optimize_query")
        
        # Compile workflow
        self.workflow = workflow.compile()
    
    async def process_question(self, user_question: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Process user question through the workflow"""
        state = {
            "user_question": user_question,
            "context": context,
            "timestamp": datetime.utcnow()
        }
        
        result = await self.workflow.ainvoke(state)
        
        return {
            "response": result.get("final_response", {}).get("content", ""),
            "sources": result.get("final_response", {}).get("sources", []),
            "metadata": {
                "sources_used": len(result.get("rag_results", [])),
                "confidence_score": result.get("final_response", {}).get("confidence_score", 0.0)
            }
        }
    
    async def _optimize_query_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize query for RAG retrieval"""
        optimized = await self.query_optimizer.optimize_query(
            state["user_question"],
            state.get("context", {})
        )
        state["optimized_query"] = optimized
        return state
    
    async def _retrieve_rag_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Retrieve from RAG"""
        rag_results = await self.rag_client.search(
            query=state["optimized_query"]["optimized_query"],
            k=state["optimized_query"]["k_value"]
        )
        state["rag_results"] = rag_results
        return state
    
    async def _generate_response_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Generate final response"""
        response = await self.response_formulator.generate_response(
            rag_results=state.get("rag_results", []),
            user_question=state["user_question"],
            query_context={"optimized_query": state.get("optimized_query", {})}
        )
        state["final_response"] = response
        return state