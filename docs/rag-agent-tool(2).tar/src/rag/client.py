"""RAG client for vector database operations"""

from typing import Dict, Any, List, Optional
from langchain.vectorstores import Chroma
from langchain.embeddings import OpenAIEmbeddings
from ..config import settings

class RAGClient:
    """Client for RAG vector database operations"""
    
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(openai_api_key=settings.openai.api_key)
        self.collection_name = settings.rag.collection_name
        self.vector_store = Chroma(
            collection_name=self.collection_name,
            embedding_function=self.embeddings,
            persist_directory="./chroma_db"
        )
    
    async def search(self, query: str, k: int = 4, filters: Optional[Dict] = None) -> List[Dict[str, Any]]:
        """Search vector database"""
        search_kwargs = {"k": k}
        if filters:
            search_kwargs["filter"] = filters
        
        results = self.vector_store.similarity_search_with_score(query, **search_kwargs)
        
        return [
            {
                "content": doc.page_content,
                "metadata": doc.metadata,
                "score": float(score)
            }
            for doc, score in results
        ]
    
    async def add_documents(self, documents: List[Dict[str, Any]]) -> bool:
        """Add documents to vector store"""
        from langchain.schema import Document
        docs = [Document(page_content=d["content"], metadata=d.get("metadata", {})) for d in documents]
        self.vector_store.add_documents(docs)
        return True