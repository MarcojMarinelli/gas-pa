"""Configuration module for RAG Agent Tool"""

import os
from typing import Dict, Any
from pydantic import BaseSettings, Field
from dotenv import load_dotenv

load_dotenv()

class OpenAIConfig(BaseSettings):
    api_key: str = Field(default=os.getenv("OPENAI_API_KEY", ""))
    model_name: str = Field(default="gpt-4-turbo-preview")
    temperature: float = Field(default=0.3)
    max_tokens: int = Field(default=1500)

class RAGConfig(BaseSettings):
    collection_name: str = Field(default="sales_acme_combo")
    default_k: int = Field(default=4)
    max_k: int = Field(default=8)
    min_k: int = Field(default=2)

class Settings:
    def __init__(self):
        self.openai = OpenAIConfig()
        self.rag = RAGConfig()

settings = Settings()

# Query enhancement rules
QUERY_ENHANCEMENT_RULES = {
    "customer_queries": {
        "include_fields": ["account_id", "deal_stage", "sfdc_obj"],
        "expand_terms": {
            "meeting": ["zoom", "calendar", "event_date"],
            "deal": ["sfdc_obj", "deal_stage", "opportunity"]
        }
    },
    "process_queries": {
        "include_fields": ["framework", "pillar"],
        "expand_terms": {
            "MEDDPICC": ["framework", "pillar", "decision process"]
        }
    }
}